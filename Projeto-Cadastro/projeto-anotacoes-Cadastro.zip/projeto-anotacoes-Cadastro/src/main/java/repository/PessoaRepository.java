package br.com.projetosaula.cadastro.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.projetosaula.cadastro.data.entity.Nota;

@Repository
public interface PessoaRepository extends JpaRepository<Pessoa, Integer> {

	public List<Pessoa> findByTituloContaining(String titulo);
}
