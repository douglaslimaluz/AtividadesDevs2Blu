package repository;

public class CadastroRepository {
	package br.com.projetosaula.cadastro.repository;

	import java.util.List;

	import org.springframework.data.jpa.repository.JpaRepository;
	import org.springframework.stereotype.Repository;

	import br.com.projetosaula.cadastro.data.entity.Categoria;

	@Repository
	public interface CadastroRepository extends JpaRepository<Cadastro, Integer>{

		public List<Categoria> findByDescricaoContaining(String descricao);
	}

}
