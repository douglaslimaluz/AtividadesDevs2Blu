package controller;

public class CadastroController {
	package br.com.projetosaula.cadastro.controller;

	import java.util.List;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.CrossOrigin;
	import org.springframework.web.bind.annotation.DeleteMapping;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.PutMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RestController;

	import br.com.projetosaula.cadastro.data.dto.CadastroDTO;
	import br.com.projetosaula.cadastro.service.CadastroService;

	@RestController
	@CrossOrigin("*")
	@RequestMapping("/api/cadastro")
	public class CadastroController {

		@Autowired
		CadastroService service;

		@GetMapping
		public List<CadastroDTO> getAll() {
			return service.getAll();
		}
		
		@GetMapping("/{id}")
		public CadastroDTO getById(@PathVariable("id") Integer id) throws Exception {
			return service.getById(id);
		}
		
		@PostMapping
		public ResponseEntity<CadastroDTO> save(@RequestBody CadastroDTO Cadastro) {
			return new ResponseEntity<CadastroDTO>(service.save(Cadastro), HttpStatus.CREATED);
		}
		
		@DeleteMapping("/{id}")
		public ResponseEntity<Boolean> delete(@PathVariable("id") Integer idCadastro) throws Exception {
			return new ResponseEntity<>(service.delete(idCadastro), HttpStatus.OK);
		}
		
		
		@PutMapping("/toggleAtivo")
		public ResponseEntity<Boolean> toggleAtivo(@RequestBody Integer idCadastro) throws Exception {
			return new ResponseEntity<>(service.toggle(idCadastro), HttpStatus.ACCEPTED);
		}
	}

}
