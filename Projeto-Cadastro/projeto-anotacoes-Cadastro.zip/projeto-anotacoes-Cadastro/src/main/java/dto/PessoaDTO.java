package dto;

public class PessoaDTO {
	package br.com.projetosaula.cadastro.data.dto;

	import java.io.Serializable;

	import br.com.projetosaula.cadastro.data.entity.Pessoa;

	public classPessoaDTO implements Serializable {
		
		private static final long serialVersionUID = 1L;
		private Integer idNota;	
		private String tituloPessoa;	
		private String textoAnotacao;	
		private cadastroDTO categoria;
		
		publicPessoaDTO() {}
		
		public Pessoa convertToEntity() {
			return new Nota(getIdPessoa(), 
							getTituloPessoa(),
							getTextoAnotacao(), 
							getcadastro().convertToEntity());
		}

		public PessoaDTO(Integer idPessoa, String tituloPessoa, String textoAnotacao, CadastroDTO Cadastro) {
			this.idPessoa = idPessoa;
			this.tituloPessoa = tituloPessoa;
			this.textoAnotacao = textoAnotacao;
			this.Cadastro = Cadastro;
		}

		public Integer getIdPessoa() {
			return idPessoa;
		}

		public void setIdPessoa(Integer idPessoa) {
			this.idPessoa = idPessoa;
		}

		public String getTituloPessoa() {
			return tituloPessoa;
		}

		public void setTituloPessoa(String tituloPessoa) {
			this.tituloPessoa = tituloPessoa;
		}

		public String getTextoAnotacao() {
			return textoAnotacao;
		}

		public void setTextoAnotacao(String textoAnotacao) {
			this.textoAnotacao = textoAnotacao;
		}

		public CategoriaDTO getCategoria() {
			return categoria;
		}

		public void setCategoria(CategoriaDTO categoria) {
			this.categoria = categoria;
		}
		
		
		
	}

}
