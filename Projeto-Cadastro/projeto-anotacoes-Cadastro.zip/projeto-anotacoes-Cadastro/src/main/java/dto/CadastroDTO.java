package dto;

public class CadastroDTO {
	package br.com.projetosaula.anotacoes.data.dto;

	import java.io.Serializable;

	import br.com.projetosaula.cadastro.data.entity.Categoria;

	public class Cadastro implements Serializable {
		
		private static final long serialVersionUID = 1L;
		
		private Integer idCadastro;
		private String  descricaoCadastro;
		private boolean flAtivo;
		
		public CadastroDTO() {}

		public Cadastro(Integer idCadastro, String descricaoCadastro, boolean flAtivo) {
			super();
			this.idCadastro = idCadastro;
			this.descricaoCadastro = descricaoCadastro;
			this.flAtivo = flAtivo;
		}
		
		public Cadastro convertToEntity() {
			return new Cadastro(getIdCadastro(), 
								getDescricaoCadastro(),
								isFlAtivo());
		}

		public Integer getIdCadastro() {
			return idCadastro;
		}

		public void setIdCadastro(Integer idCadastro) {
			this.idCadastro = idCadastro;
		}

		public String getDescricaoCadastro() {
			return descricaoCadastro;
		}

		public void setDescricaoCadastro(String descricaoCadastro) {
			this.descricaoCadastro = descricaoCadastro;
		}

		public boolean isFlAtivo() {
			return flAtivo;
		}

		public void setFlAtivo(boolean flAtivo) {
			this.flAtivo = flAtivo;
		}
		
		

	}

}
