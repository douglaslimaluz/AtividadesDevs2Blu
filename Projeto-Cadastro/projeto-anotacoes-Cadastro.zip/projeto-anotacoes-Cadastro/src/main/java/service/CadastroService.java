package service;

public class CadastroService {
	package br.com.projetosaula.cadastro.service;

	import java.util.ArrayList;
	import java.util.List;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;

	import br.com.projetosaula.cadastro.data.dto.CadastroDTO;
	import br.com.projetosaula.cadastro.data.entity.Cadastro;
	import br.com.projetosaula.cadastro.repository.CadastroRepository;

	@Service
	public class CadastroService {

		@Autowired
		CadastroRepository repository;
		
		public List<CadastroDTO> getAll() {
			List<Cadastro> Cadastro = repository.findAll();
			List<CadastroDTO> listDTOs = new ArrayList<>();
			
			for (Categoria categoria : Cadastro) {
				listDTOs.add(Cadastro.getDTO());
			}
			
			return listDTOs;
		}
		
		public CadastroDTO getById(Integer id) throws Exception {
			Cadastro Cadastro = repository.findById(id)
											.orElseThrow(
													() -> new Exception("Cadastro nÃ£o encontrada"));
			return Cadastro.getDTO();
		}
		
		public CadastroDTO save(CadastroDTO dto) {
			Cadastro Cadastro = repository.save(dto.convertToEntity());
			return Cadastro.getDTO();
		}

		public Boolean delete(Integer idCadastro) throws Exception {
			Cadastro cat = repository.findById(idCadastro)
									  .orElseThrow(() -> new Exception("Cadastro nÃ£o encontrada"));
			repository.delete(cat);
			return true;
		}

		public Boolean toggle(Integer idCadastro) throws Exception {
			Cadastro cat = repository.findById(idCadastro)
					  .orElseThrow(() -> new Exception("Cadastro nÃ£o encontrada"));
			
			cat.setFlAtivo(!cat.isFlAtivo());
			return save(cat.getDTO()).getIdCadastro() > 0;
		}
	}

}
