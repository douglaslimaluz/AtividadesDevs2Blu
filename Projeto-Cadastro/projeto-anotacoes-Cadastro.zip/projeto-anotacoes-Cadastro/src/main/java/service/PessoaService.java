package service;

public class PessoaService {
	package br.com.projetosaula.cadastro.service;

	import java.util.ArrayList;
	import java.util.List;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;

	import br.com.projetosaula.cadastro.data.dto.NotaDTO;
	import br.com.projetosaula.cadastro.data.entity.Nota;
	import br.com.projetosaula.cadastro.repository.NotaRepository;

	@Service
	public class PessoaService {

		@Autowired
		NotaRepository repository;
		
		public List<PessoaDTO> getAll() {
			List<Pessoa> Pessoas = repository.findAll();
			List<PessoaDTO> listaPessoasDTO = new ArrayList();
			
			for (Pessoas Pessoa : Pessoas) {
				listaPessoasDTO.add(Pessoa.getDTO());
			}
			return listaPessoasDTO;
		}
		
		public PessoaDTO getById(Integer id) throws Exception {
			Nota nota = repository.findById(id)
									.orElseThrow(
											() -> new Exception("Nota nÃ£o encontrada"));
			return Pessoa.getDTO();
		}

		public PessoaDTO add(PessoaDTO Pessoa) {
			return repository.save(Pessoa.convertToEntity()).getDTO();
		}

		public Boolean delete(Integer id) throws Exception {
			repository.delete(getById(id).convertToEntity());
			return true;
		}

		public NotaDTO update(NotaDTO Pessoa) throws Exception {
			getById(Pessoa.getIdNota());
			return add(Pessoa);
		}
	}

}
